#include<stdio.h>

void fun()
{
printf("Inside fun\n");
}
