#include "header.h"
#include<stdio.h>

int main()
{

printf("Inside main\n");
fun();
return 0;
}
